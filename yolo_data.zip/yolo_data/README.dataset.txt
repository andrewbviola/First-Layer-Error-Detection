# Spaghetti 3D > 2023-10-03 4:29pm
https://universe.roboflow.com/3d-printing-failure/spaghetti-3d

Provided by a Roboflow user
License: CC BY 4.0

